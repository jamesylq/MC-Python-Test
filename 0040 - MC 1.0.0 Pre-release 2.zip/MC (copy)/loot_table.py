lootTable = {
    '-1': [
        {'drop': None, 'chance': 100, 'count': 0}
    ],
    '0': [
        {'drop': None, 'chance': 100, 'count': 0}
    ],
    '1': [
        {'drop': '3', 'chance': 100, 'count': 1}
    ],
    '2': [
        {'drop': '2', 'chance': 100, 'count': 1}
    ],
    '3': [
        {'drop': '3', 'chance': 100, 'count': 1}
    ],
    '4': [
        {'drop': None, 'chance': 100, 'count': 1}
    ],
    '5': [
        {'drop': None, 'chance': 100, 'count': 1}
    ],
    '6': [
        {'drop': '6', 'chance': 100, 'count': 1}
    ],
    '7': [
        {'drop': None, 'chance': 100, 'count': 1}
    ]
}
