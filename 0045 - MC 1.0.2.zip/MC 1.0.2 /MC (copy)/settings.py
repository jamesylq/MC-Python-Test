# ----- WORLD SETTINGS -----

worldfile = 'worldsave.py'
texturesFolder = 'MCResources/'
hitboxTagFile = 'Tags/hitbox.txt'

# ----- PLAYER SETTINGS -----

reach = 4.25
jumpstrength = 25
startingHotbar = [['5', 1000], [None, 0], [None, 0], [None, 0], [None, 0], [None, 0], [None, 0], [None, 0], [None, 0]]

# ----- GENERAL SETTINGS -----

mobGriefing = True
showhitbox = False
grassSpread = True
growthSpeed = 3

# ----- ADVANCED GENERAL SETTINGS -----

grassOverlap = False

# ----- MOB SETTINGS -----
# Creeper settings
creeperExplosionPower = 10
startingcreepercount = 10
creeperreach = 3

# Pig settings
spawnPigs = True
startingpigcount = 0

# -------------------------------------
