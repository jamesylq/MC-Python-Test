# ----- WORLD SETTINGS -----

worldfile = 'preloadedWorld.txt'
texturesFolder = 'MCResources/'
hitboxTagFile = 'Tags/hitbox.txt'

# ----- PLAYER SETTINGS -----

reach = 4.25
jumpstrength = 25

# ----- GENERAL SETTINGS -----

mobGriefing = True
showhitbox = True
grassSpread = True
growthSpeed = 3

# ----- ADVANCED GENERAL SETTINGS -----

grassOverlap = False

# ----- MOB SETTINGS -----

# Creeper settings
creeperExplosionPower = 10
creepercount = 0
creeperreach = 3

# Pig settings
spawnPigs = True
startingpigcount = 0

# -------------------------------------
