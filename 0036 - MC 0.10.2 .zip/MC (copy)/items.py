import pygame
from settings import texturesFolder as imageResource

IDs = {
    '-1': {
        'name': 'air',
        'texture': pygame.image.load(imageResource + 'Air.png'),
        'itemtexture': None,
        'timetobreak': -1,
        'blastresistance': -1
    },
    '0': {
        'name': 'bedrock',
        'texture': pygame.image.load(imageResource + 'Bedrock.png'),
        'itemtexture': None,
        'timeto--break': -1,
        'blastresistance': -1
    },
    '1': {
        'name': 'grass_block',
        'texture': pygame.image.load(imageResource + 'Grass_block.png'),
        'itemtexture': pygame.image.load(imageResource + 'Grass_block_item.png'),
        'timetobreak': 10,
        'blastresistance': 5
    },
    '2': {
        'name': 'stone',
        'texture': pygame.image.load(imageResource + 'Stone.png'),
        'itemtexture': pygame.image.load(imageResource + 'Stone_item.png'),
        'timetobreak': 20,
        'blastresistance': 10
    },
    '3': {
        'name': 'dirt',
        'texture': pygame.image.load(imageResource + 'Dirt.png'),
        'itemtexture': pygame.image.load(imageResource + 'Dirt_item.png'),
        'timetobreak': 10,
        'blastresistance': 5
    },
    '4': {
        'name': 'iron_ore',
        'texture': pygame.image.load(imageResource + 'Iron_Ore.png'),
        'itemtexture': pygame.image.load(imageResource + 'Iron_Ore_Item.png'),
        'timetobreak': 40,
        'blastresistance': 15
    },
    '5': {
        'name': 'grass',
        'texture': pygame.image.load(imageResource + 'Grass.png'),
        'itemtexture': None,
        'timetobreak': 1,
        'blastresistance': 1
    },
    '6': {
        'name': 'oak_log',
        'texture': pygame.image.load(imageResource + 'Oak_log.png'),
        'itemtexture': None,
        'timetobreak': 8,
        'blastresistance': 7
    },
    '7': {
        'name': 'oak_leaves',
        'texture': pygame.image.load(imageResource + 'Oak_leaves.png'),
        'itemtexture': None,
        'timetobreak': 1,
        'blastresistance': 1
    }
}
