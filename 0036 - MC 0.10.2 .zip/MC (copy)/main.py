from typing import AnyStr
from mobs import *
import random
import pygame
import math
import settings
import functions


screen = pygame.display.set_mode((1200, 800))
pygame.init()
x = 0

clock = pygame.time.Clock()
hitboxBlocks = [line.rstrip() for line in open(settings.hitboxTagFile)]
pregenerated_world = ''
if settings.worldfile is not None:
    pregenerated_world = open(settings.worldfile, 'r').read().rstrip()
breakingTextures = [pygame.image.load(f'{settings.texturesFolder}Breaking/Break-{n}.png') for n in range(1, 5)]
alreadyRegenerated = False
mine = [0, 0, -1, 0, 1]    # bx, by, block, progress, totalProgressNeeded
mining = False
randomtickspeed = settings.growthSpeed
if randomtickspeed > 100:
    randomtickspeed = 0
else:
    randomtickspeed = 100 - randomtickspeed


class player(object):
    def __init__(self, x, y):
        self.hotbar = [[None, 0] * 9]
        self.x = x
        self.y = y
        self.hitbox = [self.x, self.y, 25, 75]
        self.bx = self.x // 50
        self.by = (self.y + self.hitbox[3]) // 50
        self.yvel = 0
        self.jumpticks = 0
        self.jumping = False
        self.reach = settings.reach
        self.timers = [0]    # 0: Jumpframes timer

    def draw(self):
        pygame.draw.rect(screen, (255, 0, 0), self.hitbox)
        if settings.showhitbox:
            pygame.draw.rect(screen, (0, 0, 255), self.hitbox, 3)
            pygame.draw.line(screen, (0, 0, 255), (mine[0] * 50 + 25, mine[1] * 50 + 25), (self.x, self.y), 5)
            pygame.draw.line(screen, (0, 255, 0), (self.x + self.hitbox[2], self.y), (mx, my), 5)

    def checkMove(self, chunks, jumpDuration=21):
        if self.jumping:
            # ----- Check for moving in air -----
            if pygame.key.get_pressed()[pygame.K_LEFT]:
                if player.x > 0 and player.checkLeft(gen.chunks):
                    player.x -= 5
            if pygame.key.get_pressed()[pygame.K_RIGHT]:
                if player.x < 1200 and player.checkRight(gen.chunks):
                    player.x += 5

            # ----- Defining how much the player should jump -----
            yvels = [settings.jumpstrength]
            for n in range(int(jumpDuration / 2) - 1):
                yvels.append(yvels[-1] / 1.01)
            yvels.append(-yvels[-1])
            for n in range(int(jumpDuration / 2) - 1):
                yvels.append(-abs(yvels[-1] * 1.01))

            for n in range(len(yvels)):
                if yvels[n] < 0:
                    yvels[n] = -math.ceil(yvels[n])
                else:
                    yvels[n] = -math.floor(yvels[n])

            self.yvel = yvels[self.jumpticks - 1]

            # ----- Timer Circuit -----
            if player.timers[0] < 2:
                player.timers[0] += 1
                self.y += round(self.yvel / 4)
                return
            else:
                player.timers[0] = 0

            # ----- If player jumps to a new square, check if that square is solid and move player down -----
            if (self.y + self.yvel) // 50 != self.y // 50:
                if not self.checkDown(chunks):
                    self.y += self.yvel
                else:
                    self.y += 50 - (self.y % 50) % 50
                    self.jumpticks = 0
                    self.jumping = False
            else:
                self.y += self.yvel

            # ----- Finalise -----
            self.hitbox = [self.x, self.y, 25, 75]
            self.bx = self.x // 50
            self.by = (self.y + self.hitbox[3]) // 50

            if jumpDuration > self.jumpticks and not self.jumpticks == 0:
                self.jumpticks += 1
                if self.jumpticks == jumpDuration:
                    self.jumpticks = 0
                    self.jumping = False
                    self.y += (50 - self.y % 50) % 50

    def move_y(self, chunks):
        chunks_to_check = []
        self.bx = self.x // 50
        self.by = (self.y + self.hitbox[3]) // 50

        if self.x % 50 <= self.hitbox[2]:
            chunks_to_check.append(self.bx)
        else:
            chunks_to_check.append(self.bx)
            chunks_to_check.append(self.bx + 1)

        if self.jumpticks == 0:
            down = True
            for xval in chunks_to_check:
                try:
                    down = not str(chunks[xval][self.by]) in hitboxBlocks
                except IndexError:
                    self.x = 0
                    self.y = 0
                    self.hitbox = [0, 0, 75, 25]
                    return
                if not down:
                    break

            if down:
                if str(chunks[self.bx][(self.y + 5) // 50]) not in hitboxBlocks:
                    self.y += 5
                else:
                    self.y += 50 - self.y % 50

        else:
            self.jumping = True
            self.checkMove(chunks)

        self.hitbox = [self.x, self.y, 25, 75]

    def checkLeft(self, chunks):
        self.bx = self.x // 50
        self.by = (self.y + self.hitbox[3]) // 50

        if self.x - 5 < 0:
            return False
        if self.x % 50 != 0:
            return True
        if self.y % 50 == 25:
            if str(chunks[self.bx - 1][self.by - 1]) in hitboxBlocks or str(chunks[self.bx - 1][self.by - 2]) in hitboxBlocks:
                return False
            return True
        else:
            if str(chunks[self.bx - 1][self.by]) in hitboxBlocks or str(chunks[self.bx - 1][self.by - 1]) in hitboxBlocks or str(chunks[self.bx - 1][self.by - 2]) in hitboxBlocks:
                return False
            return True

    def checkRight(self, chunks):
        self.bx = self.x // 50
        self.by = (self.y + self.hitbox[3]) // 50

        if self.x + 5 >= 1175:
            return False
        if self.x % 50 < 25:
            return True
        if self.y % 50 == 25:
            if str(chunks[self.bx + 1][self.by - 1]) in hitboxBlocks or str(chunks[self.bx + 1][self.by - 2]) in hitboxBlocks:
                return False
            return True
        else:
            if str(chunks[self.bx + 1][self.by]) in hitboxBlocks or str(chunks[self.bx + 1][self.by - 1]) in hitboxBlocks or str(chunks[self.bx + 1][self.by - 2]) in hitboxBlocks:
                return False
            return True

    def checkTop(self, chunks):
        if self.by - 1 < 0:
            return True
        if chunks[self.bx][self.by - 1] in hitboxBlocks:
            return False
        return True

    def checkDown(self, chunks, world_height=14):
        if math.ceil(self.y / 50) + 1 > world_height:
            return True
        if chunks[self.bx][math.ceil(self.y / 50) + 1] in hitboxBlocks:
            return False
        return True

    def addToInventory(self, block: AnyStr, count: int):
        for slot in self.hotbar:
            if slot[0] == block:
                slot[1] += count
                return True
            if slot[1] == 0:
                slot[0], slot[1] = block, count
                return True
        return False


class generator(object):
    def __init__(self, width: int):
        self.width = width
        self.chunks = []

    def generateWorld(self):
        chunks = []

        for i in range(self.width):
            # Generate Bedrock (last two layers)
            chunkdata = ['0']
            if random.randint(1, 3) == 1:
                chunkdata.append('0')
            else:
                chunkdata.append('2')

            # Generate Stone:
            for n in range(5):
                chunkdata.append('2')

            # Generate Grass:
            if random.randint(1, 2) == 1:
                chunkdata.append('3')
            else:
                chunkdata.append('2')
            chunkdata.append('1')

            # Generate Air:
            if random.randint(1, 5) <= 2:
                chunkdata.append('5')
            else:
                chunkdata.append('-1')
            for n in range(4):
                chunkdata.append('-1')

            chunkdata.reverse()
            chunks.append(chunkdata)

        self.chunks = chunks

    def generateCave(self):
        xval = random.randint(1, self.width)
        cavewidth = [random.randint(1, 3), random.randint(1, 3)]    # Width on both sides
        if xval - cavewidth[0] < 0:
            cavewidth[0] = xval - 1
        if xval + cavewidth[1] > self.width:
            cavewidth[1] = self.width - xval - 1

        caveDepth = random.randint(1, 2)
        multiplier = 1
        for n in range(sum(cavewidth) + 1):
            chunkToEdit = self.chunks[n + xval - cavewidth[0] - 1]
            chunkToEdit[2] = '-1'

            for m in range(caveDepth):
                if n in [0, sum(cavewidth) + 1] and m == caveDepth:
                    chunkToEdit[3 + m] = '1'
                else:
                    chunkToEdit[3 + m] = '-1'

            if n < ((sum(cavewidth) + 1) / 2):
                caveDepth += round(random.choice([1, 1, 1, 2]) * multiplier)
            else:
                caveDepth -= round(random.choice([1, 1, 1, 2]) * multiplier)

            multiplier *= 1.1
            if '2' not in chunkToEdit:
                chunkToEdit[-2] = '2'
            if '0' not in chunkToEdit:
                chunkToEdit[-1] = '0'

    def generateVein(self, itemID, chunks, ymin, ymax, specified_coords: None or list = None, width=None):
        if width is None:
            width = [2, 3]
        if specified_coords is None:
            specified_coords = []

        if not specified_coords:
            xval = random.randint(1, self.width) - 1
            yval = random.randint(ymin, ymax)
        else:
            xval, yval = specified_coords

        height = random.randint(1, 2)
        width = random.randint(width[0], width[1])
        if xval + width > self.width:
            width = self.width - xval
        for n in range(width):
            for m in range(height):
                if itemID == '7' and chunks[xval + n][yval + m] == '6':
                    continue
                else:
                    chunks[xval + n][yval + m] = itemID
            if n < math.floor(width / 2):
                height += random.randint(1, 2)
            else:
                height -= random.randint(1, 2)

            if yval + height > 13:
                height -= 2

    def generateTree(self):
        xpos = random.randint(0, self.width - 1)
        if self.chunks[xpos][5] != '-1':
            height = random.choice([2, 2, 2, 2, 3, 3])
            for n in range(height):
                self.chunks[xpos][4 - n] = '6'
            self.generateVein('7', self.chunks, 0, 0, [xpos - 1, 0], [3, 4])
            if height == 2 and self.chunks[xpos][2] == '-1':
                self.chunks[xpos][2] = random.choice(['6', '6', '7'])

    def draw(self):
        x, y = 0, 0

        for chunk in self.chunks:
            for block in chunk:
                screen.blit(IDs[str(block)]['texture'], (x * 50, y * 50))
                y += 1
            x += 1
            y = 0


class timer(object):
    def __init__(self):
        self.time = 0

    def tick(self):
        self.time += 1

    def reset(self):
        self.time = 0


def regenerateWorld(person: player):
    global alreadyRegenerated, x

    person.x = 0
    person.y = 0
    person.hitbox = [0, 0, 25, 50]

    if not alreadyRegenerated and pregenerated_world != '':
        world = []
        chunks = pregenerated_world.split('], [')
        for chunk in chunks:
            world.append([])
            chunk = chunk.strip('[')
            blocks = chunk.split('\', ')
            for block in blocks:
                block = block.strip('\'')
                x += 1
                block = block.strip('[[')
                block = block.strip(']]')
                if x == 336:
                    world[-1].append(block[:-1])
                else:
                    world[-1].append(block)
        gen.chunks = world
        alreadyRegenerated = True

    else:
        gen.generateWorld()
        for n in range(random.randint(2, 4)):
            gen.generateVein('4', gen.chunks, 7, 11)
        for n in range(random.randint(1, 3)):
            gen.generateCave()
        for n in range(random.randint(1, 2)):
            gen.generateTree()
        alreadyRegenerated = True
    gen.draw()
    pygame.display.update()


def drawrect(scr: pygame.SurfaceType, pos: [int, int], colour: [int, int, int], transparency: int, length: int, width: int):
    rect = pygame.Surface((length, width), pygame.SRCALPHA)
    rect.fill([colour[0], colour[1], colour[2], transparency])
    scr.blit(rect, pos)


player = player(0, 0)
gen = generator(24)
regenerateWorld(player)
ticksPassed = timer()

pigs = []
for n in range(settings.startingpigcount):
    pigs.append(pig(random.randint(1, 1100), 0))
creepers = []
for n in range(settings.creepercount):
    creepers.append(creeper(random.randint(1, 1100), 0))


def select(x: int, y: int, w: int, h: int):
    pygame.draw.rect(screen, (128, 128, 128), (x, y, w, h), 4)
    pygame.display.update()


def checkSelect():
    global mine

    dx = player.x - mx
    dy = player.y - my
    currently_checking = [player.x, player.y]
    minesave = mine

    if dx < dy:
        movex = 0
        movey = 1
        if dy != 0:
            movex = abs(dx) / abs(dy)
        if mx < player.x:
            movex = -movex
        if my < player.y:
            movey = -1
        for n in range(abs(dy)):
            currently_checking[0] += movex
            currently_checking[1] += movey
            bx = currently_checking[0] // 50
            by = currently_checking[1] // 50
            if gen.chunks[int(bx)][int(by)] != '-1' and math.sqrt(abs(player.bx - bx) ** 2 + abs(player.by - by) ** 2) < player.reach:
                mine[0], mine[1], mine[2] = int(bx), int(by), gen.chunks[int(bx)][int(by)]
                mine[4] = IDs[mine[2]]['timetobreak']
                if (mine[0], mine[1], mine[2], mine[4]) != (minesave[0], minesave[1], minesave[2], minesave[4]):
                    mine[3] = 0
                select(bx * 50, by * 50, 50, 50)
                if mine[3] != 0 and mine[3] != mine[4]:
                    screen.blit(breakingTextures[int(mine[3] / mine[4] * 5 - 1)], (bx * 50, by * 50))
                return
    else:
        movex = 1
        movey = 0
        if dx != 0:
            movey = abs(dy) / abs(dx)
        if mx < player.x:
            movex = -1
        if my < player.y:
            movey = -movey
        for n in range(abs(dx)):
            currently_checking[0] += movex
            currently_checking[1] += movey
            bx = currently_checking[0] // 50
            by = currently_checking[1] // 50
            if gen.chunks[int(bx)][int(by)] != '-1' and math.sqrt(abs(player.bx - bx) ** 2 + abs(player.by - by) ** 2) < player.reach:
                mine[0], mine[1], mine[2] = int(bx), int(by), gen.chunks[int(bx)][int(by)]
                mine[4] = IDs[mine[2]]['timetobreak']
                if (mine[0], mine[1], mine[2], mine[4]) != (minesave[0], minesave[1], minesave[2], minesave[4]):
                    mine[3] = 0
                select(bx * 50, by * 50, 50, 50)
                if mine[3] != 0 and mine[3] != mine[4]:
                    screen.blit(breakingTextures[int(mine[3] / mine[4] * 5 - 1)], (bx * 50, by * 50))
                return


def spawn(generator: generator, mob: str = None):
    if mob == 'pig' or mob is None:
        x, y = 0, 0
        for chunk in generator.chunks:
            for block in chunk:
                try:
                    if block == '1' and generator.chunks[x][y - 1] == '-1' and random.randint(1, 10000) == 1:
                        pigs.append(pig(x * 50, y * 50 - 25))
                    y += 1
                except IndexError:
                    pass
            x += 1
            y = 0

    if mob == 'creeper' or mob is None:
        x, y = 0, 0
        for chunk in generator.chunks:
            for _ in chunk:
                try:
                    if generator.chunks[x][y + 1] in hitboxBlocks and abs(x - player.bx) > 3 and abs(y - player.by) > 3:
                        try:
                            success = True
                            for n in range(y):
                                if generator.chunks[x][n] in hitboxBlocks:
                                    success = False
                                    print(generator.chunks[x][n])
                            if success and random.randint(1, 10000) == 1:
                                creepers.append(creeper(x * 50, y * 50 - 75))
                        except IndexError:
                            pass
                except IndexError:
                    pass
                y += 1
            x += 1
            y = 0


def iterate():
    screen.fill((0, 0, 0))

    gen.draw()
    player.draw()
    player.move_y(gen.chunks)
    if settings.spawnPigs:
        spawn(gen)
    for pig in pigs:
        pig.move(gen, hitboxBlocks)
        pig.draw(screen)
    for creeper in creepers:
        creeper.move(gen, hitboxBlocks, player)
        if settings.mobGriefing:
            creeper.checkExplode(gen, player)
        creeper.draw(screen, player)

    try:
        if gen.chunks[mbx][mby] != '-1':
            checkSelect()
    except IndexError:
        pass

    ticksPassed.tick()
    if ticksPassed.time >= randomtickspeed:
        ticksPassed.reset()
        if settings.grassSpread:
            functions.spreadGrass(gen)

    pygame.display.update()

    if pygame.event.get(pygame.QUIT):
        pygame.quit()
        quit()


while True:
    mx, my = pygame.mouse.get_pos()
    mbx, mby = mx // 50, my // 50

    iterate()

    if pygame.event.get(pygame.QUIT):
        pygame.quit()
        quit()

    if pygame.key.get_pressed()[pygame.K_LEFT]:
        if player.x > 0 and player.checkLeft(gen.chunks):
            player.x -= 5
    if pygame.key.get_pressed()[pygame.K_RIGHT]:
        if player.x < 1200 and player.checkRight(gen.chunks):
            player.x += 5
    if pygame.key.get_pressed()[pygame.K_UP]:
        if not player.checkDown(gen.chunks, 14) and player.jumpticks == 0:
            player.jumpticks = 1
    if pygame.key.get_pressed()[pygame.K_k]:
        print(gen.chunks)

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                mining = True
            if event.key == pygame.K_r:
                player.x = 0
                player.y = 0
                regenerateWorld(player)
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_m:
                mining = False
                mine[3] = 0

    if pygame.event.get(pygame.QUIT):
        quit()

    if player.y % 25 == player.y % 50 == 0:
        player.y += 25

    if mining and mine[3] != mine[4] and mine[4] > 0:
        mine[3] += 1

    if mine[3] == mine[4]:
        gen.chunks[mine[0]][mine[1]] = '-1'
        mine[3] = 0
        mining = False

    for x in range(len(gen.chunks)):
        for y in range(len(gen.chunks[x])):
            try:
                if gen.chunks[x][y] == '5' and gen.chunks[x][y + 1] == '-1':
                    gen.chunks[x][y] = '-1'
            except IndexError:
                gen.chunks[x][y] = '-1'

    clock.tick(60)
