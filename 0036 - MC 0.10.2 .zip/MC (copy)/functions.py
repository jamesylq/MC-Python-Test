import random
import settings


hitboxBlocks = [line.rstrip() for line in open(settings.hitboxTagFile)]


def spreadGrass(generator):
    x, y = 0, 0
    for chunk in generator.chunks:
        for block in chunk:
            if block == '3':
                chance = 0
                for xval in range(3):
                    for yval in range(3):
                        if x + xval - 1 < 0 or y + yval - 1 < 0:
                            continue
                        try:
                            if generator.chunks[x + xval - 1][y + yval - 1] == '1':
                                chance += 20
                        except IndexError:
                            continue
                if y - 1 >= 0 and not settings.grassOverlap:
                    try:
                        if generator.chunks[x][y - 1] in hitboxBlocks:
                            chance = 0
                    except IndexError:
                        pass
                if random.randint(1, 100) <= chance:
                    generator.chunks[x][y] = '1'
            y += 1
        x += 1
        y = 0
