import random

# ----+++ DO NOT MODIFY ANYTHING ABOVE THIS LINE +++----
# ----- WORLD SETTINGS -----

worldfile = 'preloadedWorld.txt'
texturesFolder = 'MCResources/'
hitboxTagFile = 'Tags/hitbox.txt'

# ----- PLAYER SETTINGS -----

reach = 3

# ----- MOB SETTINGS -----
# General settings
mobGriefing = True

# Creeper settings
creeperExplosionPower = 10
creepercount = 100
creeperreach = 3

# Pig settings
pigcount = 1
