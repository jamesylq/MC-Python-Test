# ----- WORLD SETTINGS -----

worldfile = 'preloadedWorld.txt'
texturesFolder = 'MCResources/'
hitboxTagFile = 'Tags/hitbox.txt'

# ----- PLAYER SETTINGS -----

reach = 3
