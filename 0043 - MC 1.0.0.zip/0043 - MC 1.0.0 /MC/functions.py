import random
import settings
import math
import loot_table

from typing import *

hitboxBlocks = [line.rstrip() for line in open(settings.hitboxTagFile)]


def findDistance(pos1: [SupportsFloat, SupportsFloat], pos2: [SupportsFloat, SupportsFloat]) -> float:
    return abs(math.sqrt(abs(pos1[0] - pos2[0]) ** 2 + abs(pos1[1] - pos2[1]) ** 2))


def spreadGrass(generator):
    x, y = 0, 0
    for chunk in generator.chunks:
        for block in chunk:
            if block == '3':
                chance = 0
                for xval in range(3):
                    for yval in range(3):
                        if x + xval - 1 < 0 or y + yval - 1 < 0:
                            continue
                        try:
                            if generator.chunks[x + xval - 1][y + yval - 1] == '1':
                                chance += 20
                        except IndexError:
                            continue
                if y - 1 >= 0 and not settings.grassOverlap:
                    try:
                        if generator.chunks[x][y - 1] in hitboxBlocks:
                            chance = 0
                    except IndexError:
                        pass
                if random.randint(1, 100) <= chance:
                    generator.chunks[x][y] = '1'
            y += 1
        x += 1
        y = 0


def on_break(player, blockBroken):
    loot = loot_table.lootTable[blockBroken]
    randomLoot = random.randint(1, 100)
    covered = 0
    for dictionary in loot:
        covered += dictionary['chance']
        if covered > randomLoot and dictionary['drop'] is not None:
            player.addToInventory(dictionary['drop'], dictionary['count'])
            return


def place_block(player, hotbar, chunks: List[List[AnyStr]]):
    if chunks[int(player.selected[0] // 50)][int(player.selected[1] // 50)] != '-1' and player.hotbar[hotbar.selected][1] > 0:
        block_holding = hotbar.hotbar[hotbar.selected]
        x, y = player.selected
        found = False

        dx, dy = player.direction
        if abs(dx) == 1:
            dx /= dy
            dy = 1
        else:
            dy /= dx
            dx = 1
        while not found:
            x -= dx
            y -= dy
            if x // 50 != player.selected[0] // 50 or y // 50 != player.selected[1] // 50:
                found = True
        try:
            illegals = [[player.bx, player.y // 50], [player.bx, player.y // 50 + 1]]
            brx, bry = int(x // 50), int(y // 50)
            if chunks[brx][bry] not in hitboxBlocks and brx >= 0 <= bry and [brx, bry] not in illegals:
                chunks[brx][bry] = block_holding[0]
                player.hotbar[hotbar.selected][1] -= 1
                if player.hotbar[hotbar.selected][1] == 0:
                    player.hotbar[hotbar.selected][0] = None
        except IndexError:
            pass
