import math
import random
import functions

from items import *
from mobTextures import *
from settings import *


class pig(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.hitbox = [self.x, self.y, 50, 15]
        self.realx, self.realy = self.x + 25, self.y + 7
        self.target = [-1, 'right']

    def update(self):
        self.hitbox = [self.x, self.y, 50, 15]
        self.realx, self.realy = self.x + 25, self.y + 7

    def draw(self, scr):
        if showhitbox:
            pygame.draw.rect(scr, (255, 255, 0), self.hitbox, 5)
        scr.blit(Mobs['Pig'][self.target[1]], (self.x, self.y))

    def move(self, generator, hitboxBlocks):
        movement = {
            'left': -5,
            'right': 5
        }

        if self.target[1] == 'left':
            if self.x < self.target[0]:
                self.getNewTarget()
        else:
            if self.x > self.target[0]:
                self.getNewTarget()

        newx = self.x + movement[self.target[1]]
        if self.target[1] == 'left':
            if generator.chunks[newx // 50][self.y // 50] not in hitboxBlocks:
                self.x = newx
            else:
                self.getNewTarget()
        elif self.target[1] == 'right':
            try:
                if generator.chunks[newx // 50 + 1][self.y // 50] not in hitboxBlocks:
                    self.x = newx
                else:
                    self.getNewTarget()
            except IndexError:
                self.getNewTarget()

        self.update()

        if self.target[1] == 'left' and self.x <= self.target[0] or self.target[1] == 'right' and self.x >= self.target[0]:
            self.getNewTarget()

        chunks_to_check = []
        if self.x % 50 == 0:
            chunks_to_check.append(self.x // 50)
        else:
            chunks_to_check.append(self.x // 50)
            chunks_to_check.append(self.x // 50 + 1)

        down = True
        for chunk in chunks_to_check:
            try:
                if generator.chunks[chunk][(self.y + 20) // 50] in hitboxBlocks:
                    down = False
            except IndexError:
                self.x, self.y = 0, 0
                self.update()

        if down:
            self.y += 5

        self.update()

    def getNewTarget(self):
        self.target = [random.randint(1, 1200 - self.hitbox[3])]
        if self.target[0] > self.x:
            self.target.append('right')
        else:
            self.target.append('left')


class creeper(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.lastIdleTick = 0
        self.hitbox = [self.x, self.y, 30, 75]
        self.dead = False
        self.foundTarget = False
        self.goingToExplode = False
        self.explosionTimer = 0

    def draw(self, scr, player):
        if not self.dead:
            if showhitbox:
                pygame.draw.rect(scr, (255, 255, 0), self.hitbox, 5)
                if not self.goingToExplode:
                    pygame.draw.circle(scr, (255, 255, 0), (round(self.x), round(self.y)), 150, 5)
                else:
                    pygame.draw.rect(scr, (255, 0, 0), (self.x - 100, self.y - 100, 200, 200), 5)
                if self.foundTarget:
                    pygame.draw.line(scr, (255, 255, 0), (self.x + self.hitbox[2] / 2, self.y + self.hitbox[3] / 2), (player.x + player.hitbox[2] / 2, player.y + player.hitbox[3] / 2), 5)
            scr.blit(Mobs['Creeper'], (self.x, self.y))

    def update(self):
        self.hitbox = [self.x, self.y, 30, 75]

    def move(self, generator, hitboxBlocks, player):
        if self.dead:
            return
        try:
            if generator.chunks[self.x // 50][(self.y + 25) // 50 + 1] not in hitboxBlocks:
                self.y += 5
        except IndexError:
            self.dead = True
            return

        self.update()

        if self.goingToExplode:
            return

        if functions.findDistance([player.bx, player.by], [self.x // 50, self.y // 50]) < 7:
            self.foundTarget = True
            if random.randint(1, 2) == 1:
                if player.x > self.x:
                    self.x += 5
                    if generator.chunks[self.x // 50][(self.y + 25) // 50] in hitboxBlocks or generator.chunks[self.x // 50][(self.y + 25) // 50] in hitboxBlocks:
                        self.checkIfJump(False, generator, hitboxBlocks)
                else:
                    self.x -= 5
                    if generator.chunks[self.x // 50][(self.y + 25) // 50] in hitboxBlocks or generator.chunks[self.x // 50][(self.y + 25) // 50] in hitboxBlocks:
                        self.checkIfJump(True, generator, hitboxBlocks)

            self.update()

        else:
            self.foundTarget = False
            if self.lastIdleTick < 10:
                self.lastIdleTick += 1
            else:
                self.lastIdleTick = 0
                movement = random.randint(-5, 5)
                bx, by = self.x // 50, (self.y + 25) // 50
                try:
                    if generator.chunks[(self.x + movement) // 50][by] in hitboxBlocks or generator.chunks[(self.x + movement) // 50][by - 1] in hitboxBlocks:
                        self.checkIfJump(movement < 0, generator, hitboxBlocks)
                    self.x += movement
                except IndexError:
                    pass

        self.update()

    def checkIfJump(self, moveLeft: bool, generator, hitboxBlocks):
        if self.dead:
            return

        self.update()

        try:
            if moveLeft:
                if generator.chunks[self.x // 50 - 1][self.y // 50 - 1] not in hitboxBlocks and generator.chunks[self.x // 50 - 1][self.y // 50 - 2]:
                    self.y -= 50

                    self.update()
            else:
                if generator.chunks[(self.x + self.hitbox[3]) // 50 + 1][self.y // 50 - 1] not in hitboxBlocks and generator.chunks[(self.x + self.hitbox[3]) // 50 + 1][self.y // 50 - 2]:
                    self.y -= 50

                    self.update()
        except IndexError:
            self.y -= 50

            self.update()

    def checkExplode(self, generator, player):
        if self.dead:
            return

        explosionPower = creeperExplosionPower
        if abs(math.sqrt(abs(self.x // 50 - player.bx) ** 2 + abs(self.y // 50 - player.by) ** 2)) <= creeperreach:
            if not self.goingToExplode:
                self.goingToExplode = True
                self.explosionTimer = 0

        if self.goingToExplode:
            if self.explosionTimer < 100:
                self.explosionTimer += 1
            else:
                self.dead = True

                if mobGriefing:
                    bx, by = self.x // 50, self.y // 50
                    for x in range(5):
                        if bx - 2 + x < 0:
                            continue
                        for y in range(5):
                            try:
                                block = generator.chunks[bx - 2 + x][by - 2 + y]
                            except IndexError:
                                continue
                            else:
                                if by - 2 + y < 0:
                                    continue
                                if IDs[block]['blastresistance'] <= explosionPower:
                                    chance = 100
                                    if IDs[block]['blastresistance'] < 0:
                                        chance = -1
                                else:
                                    chance = (IDs[block]['blastresistance'] - explosionPower) * 10

                                if chance > 100:
                                    chance = 100

                                if random.randint(1, 100) <= chance:
                                    generator.chunks[bx - 2 + x][by - 2 + y] = '-1'
