import pygame
from settings import texturesFolder as imageResources

Mobs = {
    'Pig': {
            'left': pygame.image.load(imageResources + '/Mobs/Pig_left.png'),
            'right': pygame.image.load(imageResources + '/Mobs/Pig_right.png')
            },
    'Creeper': pygame.image.load(imageResources + '/Mobs/Creeper.png')
}
