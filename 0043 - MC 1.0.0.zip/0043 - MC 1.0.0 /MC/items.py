from settings import texturesFolder as imageResource

IDs = {
    '-1': {
        'name': 'air',
        'texture': (imageResource + 'Air.png'),
        'itemtexture': None,
        'timetobreak': -1,
        'blastresistance': -1
    },
    '0': {
        'name': 'bedrock',
        'texture': (imageResource + 'Bedrock.png'),
        'itemtexture': None,
        'timetobreak': -1,
        'blastresistance': -1
    },
    '1': {
        'name': 'grass_block',
        'texture': (imageResource + 'Grass_Block.png'),
        'itemtexture': (imageResource + 'Grass_Block_Item.png'),
        'timetobreak': 10,
        'blastresistance': 5
    },
    '2': {
        'name': 'stone',
        'texture': (imageResource + 'Stone.png'),
        'itemtexture': (imageResource + 'Stone_Item.png'),
        'timetobreak': 20,
        'blastresistance': 10
    },
    '3': {
        'name': 'dirt',
        'texture': (imageResource + 'Dirt.png'),
        'itemtexture': (imageResource + 'Dirt_Item.png'),
        'timetobreak': 10,
        'blastresistance': 5
    },
    '4': {
        'name': 'iron_ore',
        'texture': (imageResource + 'Iron_Ore.png'),
        'itemtexture': (imageResource + 'Iron_Ore_Item.png'),
        'timetobreak': 40,
        'blastresistance': 15
    },
    '5': {
        'name': 'grass',
        'texture': (imageResource + 'Grass.png'),
        'itemtexture': None,
        'timetobreak': 1,
        'blastresistance': 1
    },
    '6': {
        'name': 'oak_log',
        'texture': (imageResource + 'Oak_Log.png'),
        'itemtexture': (imageResource + 'Oak_Log_Item.png'),
        'timetobreak': 8,
        'blastresistance': 7
    },
    '7': {
        'name': 'oak_leaves',
        'texture': (imageResource + 'Oak_Leaves.png'),
        'itemtexture': None,
        'timetobreak': 1,
        'blastresistance': 1
    }
}
